package diana.padilla.programaciondiana

class Calculadora {
    fun Sumar(num1: Int, num2: Int): Int {
        val resultado = num1+num2
        return resultado
    }

    fun Restar(num1: Int, num2: Int): Int {
        val resultado = num1-num2
        return resultado
    }

    fun Multiplicar(num1: Int, num2: Int): Int {
        val resultado = num1*num2
        return resultado
    }
}